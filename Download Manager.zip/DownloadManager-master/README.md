Description
A small download manager in .Net


Prerequisites
Visusal Studio 2012
